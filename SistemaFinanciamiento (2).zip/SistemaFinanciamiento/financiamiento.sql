CREATE DATABASE financiamientoBiene
GO

USE financiamientoBiene
GO

CREATE TABLE roles (
    id_rol INT IDENTITY(1,1) PRIMARY KEY,
    nombre_rol VARCHAR(50) UNIQUE
)
GO

CREATE TABLE usuarios (
    id_usuario INT IDENTITY(1,1) PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    password_hash VARCHAR(255),
    id_rol INT,
    FOREIGN KEY (id_rol) REFERENCES roles(id_rol)
)
GO

CREATE TABLE departamento (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo VARCHAR(20),
    descripcion VARCHAR(100)
)
GO

CREATE TABLE municipio (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo VARCHAR(20),
    descripcion VARCHAR(100),
    departamento_id INT,
    FOREIGN KEY (departamento_id) REFERENCES departamento(id)
)
GO

CREATE TABLE cliente (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo VARCHAR(20),
    nombres VARCHAR(100),
    apellido1 VARCHAR(50),
    apellido2 VARCHAR(50),
    direccion VARCHAR(255),
    telefono VARCHAR(20),
    municipio_id INT,
    FOREIGN KEY (municipio_id) REFERENCES municipio(id)
)
GO

CREATE TABLE asesores (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo VARCHAR(20),
    nombres VARCHAR(100),
    apellido1 VARCHAR(50),
    apellido2 VARCHAR(50),
    direccion VARCHAR(255),
    telefono VARCHAR(20),
    id_usuario INT,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
)
GO

CREATE TABLE tipo_bien (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo VARCHAR(20),
    descripcion VARCHAR(100)
)
GO

CREATE TABLE contrato (
    id INT IDENTITY(1,1) PRIMARY KEY,
    codigo VARCHAR(20),
    descripcion VARCHAR(255),
    monto_financiado DECIMAL(15,2) CHECK (monto_financiado >= 0),
    interes DECIMAL(5,2) CHECK (interes >= 0),
    cliente_id INT,
    tipo_bien_id INT,
    asesor_id INT,
    fecha DATE,
    plazo INT CHECK (plazo > 0),
    monto_prima DECIMAL(15,2) CHECK (monto_prima >= 0),
    FOREIGN KEY (cliente_id) REFERENCES cliente(id),
    FOREIGN KEY (tipo_bien_id) REFERENCES tipo_bien(id),
    FOREIGN KEY (asesor_id) REFERENCES asesores(id)
)
GO

CREATE TABLE pagos (
    id INT IDENTITY(1,1) PRIMARY KEY,
    contrato_id INT,
    numero_cuota INT,
    fecha DATE,
    monto_pagado DECIMAL(15,2) CHECK (monto_pagado >= 0),
    capital DECIMAL(15,2),
    interes DECIMAL(15,2),
    mora DECIMAL(15,2),
    saldo DECIMAL(15,2),
    id_usuario INT,
    FOREIGN KEY (contrato_id) REFERENCES contrato(id),
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
)
GO

INSERT INTO tipo_bien (codigo, descripcion) VALUES
('TB01','casa'),
('TB02','terreno'),
('TB03','vehiculo')
GO

INSERT INTO roles (nombre_rol) VALUES
('administrador'),
('vendedor'),
('cobrador')
GO

INSERT INTO usuarios (username, password_hash, id_rol) VALUES
('admin','123',1),
('vendedor1','456',2),
('cobrador1','789',3)
GO

INSERT INTO departamento (codigo, descripcion) VALUES
('D01','Managua'),
('D02','Le�n')
GO

INSERT INTO municipio (codigo, descripcion, departamento_id) VALUES
('M01','Distrito 1',1),
('M02','Distrito 2',1)
GO

INSERT INTO cliente (codigo, nombres, apellido1, apellido2, direccion, telefono, municipio_id) VALUES
('C001','Juan','Perez','Lopez','Barrio X','88888888',1)
GO

INSERT INTO asesores (codigo, nombres, apellido1, apellido2, direccion, telefono, id_usuario) VALUES
('A001','Carlos','Gomez','Ruiz','Zona Y','77777777',2)
GO

CREATE PROCEDURE sp_crear_usuario
    @username VARCHAR(50),
    @password VARCHAR(255),
    @id_rol INT
AS
BEGIN
    INSERT INTO usuarios (username, password_hash, id_rol)
    VALUES (@username, CONVERT(VARCHAR(255), HASHBYTES('SHA2_256', @password), 2), @id_rol)
END
GO

CREATE PROCEDURE sp_login_seguro
    @username VARCHAR(50),
    @password VARCHAR(255)
AS
BEGIN
    SELECT id_usuario, username, id_rol
    FROM usuarios
    WHERE username = @username
    AND password_hash = CONVERT(VARCHAR(255), HASHBYTES('SHA2_256', @password), 2)
END
GO

CREATE PROCEDURE sp_insertar_cliente
    @codigo VARCHAR(20),
    @nombres VARCHAR(100),
    @apellido1 VARCHAR(50),
    @apellido2 VARCHAR(50),
    @direccion VARCHAR(255),
    @telefono VARCHAR(20),
    @municipio_id INT
AS
BEGIN
    INSERT INTO cliente (
        codigo,
        nombres,
        apellido1,
        apellido2,
        direccion,
        telefono,
        municipio_id
    )
    VALUES (
        @codigo,
        @nombres,
        @apellido1,
        @apellido2,
        @direccion,
        @telefono,
        @municipio_id
    )
END
GO

CREATE PROCEDURE sp_crear_contrato
    @codigo VARCHAR(20),
    @descripcion VARCHAR(255),
    @monto DECIMAL(15,2),
    @interes DECIMAL(5,2),
    @cliente_id INT,
    @tipo_bien_id INT,
    @asesor_id INT,
    @fecha DATE,
    @plazo INT,
    @prima DECIMAL(15,2)
AS
BEGIN
    INSERT INTO contrato (
        codigo,
        descripcion,
        monto_financiado,
        interes,
        cliente_id,
        tipo_bien_id,
        asesor_id,
        fecha,
        plazo,
        monto_prima
    )
    VALUES (
        @codigo,
        @descripcion,
        @monto,
        @interes,
        @cliente_id,
        @tipo_bien_id,
        @asesor_id,
        @fecha,
        @plazo,
        @prima
    )
END
GO

CREATE PROCEDURE sp_registrar_pago
    @contrato_id INT,
    @numero_cuota INT,
    @fecha DATE,
    @monto_pagado DECIMAL(15,2),
    @capital DECIMAL(15,2),
    @interes DECIMAL(15,2),
    @mora DECIMAL(15,2),
    @saldo DECIMAL(15,2),
    @id_usuario INT
AS
BEGIN
    INSERT INTO pagos (
        contrato_id,
        numero_cuota,
        fecha,
        monto_pagado,
        capital,
        interes,
        mora,
        saldo,
        id_usuario
    )
    VALUES (
        @contrato_id,
        @numero_cuota,
        @fecha,
        @monto_pagado,
        @capital,
        @interes,
        @mora,
        @saldo,
        @id_usuario
    )
END
GO

CREATE PROCEDURE sp_generar_amortizacion_avanzado
    @contrato_id INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM pagos WHERE contrato_id = @contrato_id)
    BEGIN
        RAISERROR('Ya existe amortizacion para este contrato',16,1)
        RETURN
    END

    DECLARE
        @monto DECIMAL(15,2),
        @tasa DECIMAL(10,6),
        @plazo INT,
        @cuota DECIMAL(15,2),
        @saldo DECIMAL(15,2),
        @interes DECIMAL(15,2),
        @capital DECIMAL(15,2),
        @i INT = 1,
        @fecha DATE

    SELECT
        @monto = monto_financiado,
        @tasa = interes / 100.0 / 12,
        @plazo = plazo,
        @fecha = fecha
    FROM contrato
    WHERE id = @contrato_id

    SET @cuota = @monto * (@tasa * POWER(1 + @tasa, @plazo)) / (POWER(1 + @tasa, @plazo) - 1)

    SET @saldo = @monto

    WHILE @i <= @plazo
    BEGIN
        SET @interes = @saldo * @tasa
        SET @capital = @cuota - @interes
        SET @saldo = @saldo - @capital

        INSERT INTO pagos (
            contrato_id,
            numero_cuota,
            fecha,
            monto_pagado,
            capital,
            interes,
            mora,
            saldo,
            id_usuario
        )
        VALUES (
            @contrato_id,
            @i,
            DATEADD(MONTH,@i,@fecha),
            0,
            @capital,
            @interes,
            0,
            @saldo,
            3
        )

        SET @i = @i + 1
    END
END
GO

CREATE PROCEDURE sp_historial_pagos_cliente
    @cliente_id INT
AS
BEGIN
    SELECT
        p.id,
        p.numero_cuota,
        p.fecha,
        p.monto_pagado,
        p.capital,
        p.interes,
        p.mora,
        p.saldo
    FROM pagos p
    INNER JOIN contrato c
    ON p.contrato_id = c.id
    WHERE c.cliente_id = @cliente_id
END
GO

CREATE PROCEDURE sp_contratos_cliente
    @cliente_id INT
AS
BEGIN
    SELECT *
    FROM contrato
    WHERE cliente_id = @cliente_id
END
GO

CREATE PROCEDURE sp_saldo_contrato
    @contrato_id INT
AS
BEGIN
    SELECT TOP 1 saldo
    FROM pagos
    WHERE contrato_id = @contrato_id
    ORDER BY numero_cuota DESC
END
GO

CREATE PROCEDURE sp_reporte_cliente
    @cliente_id INT
AS
BEGIN
    SELECT
        c.nombres,
        c.apellido1,
        con.codigo,
        con.descripcion,
        con.monto_financiado,
        p.numero_cuota,
        p.monto_pagado,
        p.saldo
    FROM cliente c
    INNER JOIN contrato con
    ON c.id = con.cliente_id
    INNER JOIN pagos p
    ON con.id = p.contrato_id
    WHERE c.id = @cliente_id
END
GO

CREATE TRIGGER trg_validar_pago
ON pagos
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE monto_pagado < 0
    )
    BEGIN
        RAISERROR('El monto no puede ser negativo',16,1)
        RETURN
    END

    INSERT INTO pagos (
        contrato_id,
        numero_cuota,
        fecha,
        monto_pagado,
        capital,
        interes,
        mora,
        saldo,
        id_usuario
    )
    SELECT
        contrato_id,
        numero_cuota,
        fecha,
        monto_pagado,
        capital,
        interes,
        mora,
        saldo,
        id_usuario
    FROM inserted
END
GO

CREATE TRIGGER trg_validar_contrato
ON contrato
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM inserted
        WHERE cliente_id IS NULL
    )
    BEGIN
        RAISERROR('El contrato debe tener cliente',16,1)
        RETURN
    END

    INSERT INTO contrato (
        codigo,
        descripcion,
        monto_financiado,
        interes,
        cliente_id,
        tipo_bien_id,
        asesor_id,
        fecha,
        plazo,
        monto_prima
    )
    SELECT
        codigo,
        descripcion,
        monto_financiado,
        interes,
        cliente_id,
        tipo_bien_id,
        asesor_id,
        fecha,
        plazo,
        monto_prima
    FROM inserted
END
GO

CREATE TRIGGER trg_validar_rol_pago
ON pagos
AFTER INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM inserted i
        INNER JOIN usuarios u
        ON i.id_usuario = u.id_usuario
        INNER JOIN roles r
        ON u.id_rol = r.id_rol
        WHERE r.nombre_rol <> 'cobrador'
    )
    BEGIN
        RAISERROR('Solo el cobrador puede registrar pagos',16,1)
        ROLLBACK TRANSACTION
    END
END
GO

CREATE TRIGGER trg_validar_rol_contrato
ON contrato
AFTER INSERT
AS
BEGIN
    IF EXISTS (
        SELECT 1
        FROM inserted i
        INNER JOIN asesores a
        ON i.asesor_id = a.id
        INNER JOIN usuarios u
        ON a.id_usuario = u.id_usuario
        INNER JOIN roles r
        ON u.id_rol = r.id_rol
        WHERE r.nombre_rol <> 'vendedor'
    )
    BEGIN
        RAISERROR('Solo un vendedor puede crear contratos',16,1)
        ROLLBACK TRANSACTION
    END
END
GO