
using Microsoft.EntityFrameworkCore;
using SistemaFinanciamiento.Models;

namespace SistemaFinanciamiento.Data;

public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<Cliente> Clientes => Set<Cliente>();
}
